//
//  UIColor.swift
//  Preachers
//
//  Created by Abel Anca on 10/15/15.
//  Copyright © 2015 Abel Anca. All rights reserved.
//

import UIKit

extension UIColor {
    class func color(red: Double, green: Double, blue: Double, alpha: Double) -> UIColor {
        return UIColor(red: CGFloat(red / 255.0), green: CGFloat(green / 255.0), blue: CGFloat(blue / 255.0), alpha: CGFloat(alpha))
    }
    
    class func preachersBlue() -> UIColor {
        return UIColor.color(22, green: 165, blue: 245, alpha: 1)
    }
}
