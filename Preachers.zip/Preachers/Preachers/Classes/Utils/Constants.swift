//
//  Constants.swift
//  Preachers
//
//  Created by Abel Anca on 9/22/15.
//  Copyright © 2015 Abel Anca. All rights reserved.
//

import Foundation
import UIKit

/**
**     Key set in User Defaults to save logged in user's ID
**/
let k_UserDef_LoggedInUserID                    = "Logged in user id"
let k_UserAnonymous                             = "User anonymous"

let k_ResizeTo30PercentResolution: CGFloat         = 400