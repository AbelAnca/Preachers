//
//  PPreachVC.swift
//  Preachers
//
//  Created by Abel Anca on 10/14/15.
//  Copyright © 2015 Abel Anca. All rights reserved.
//

import UIKit
import Parse

class PPreachVC: UIViewController {

    @IBOutlet var lblBiblicalText: UILabel!
    @IBOutlet var lblPreach: UILabel!
    @IBOutlet var lblObservation: UILabel!
    
    @IBOutlet var btnBack: UIButton!
    
    var objId: String?
    var currentPreach: PFObject?
    
    // MARK: - ViewController Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        loadParams()
    }
    
    // MARK: - Custom Methods
    
    func setupUI() {
        btnBack.layer.cornerRadius         = 17
        btnBack.layer.borderWidth          = 0.5
        btnBack.layer.borderColor          = UIColor.whiteColor().CGColor
        btnBack.clipsToBounds              = true
    }
    
    func loadParams() {
        if let objectId = objId {
            let query = PFQuery(className:"Preach")
            query.getObjectInBackgroundWithId(objectId, block: { (object, error) -> Void in
                if error == nil {
                    self.currentPreach = object
                    self.updateParams()
                }
            })
        }
    }
    
    func updateParams() {
        if let preach = currentPreach {
            lblBiblicalText.text            = preach.objectForKey("biblicalText") as? String
            lblObservation.text             = preach.objectForKey("observation") as? String
            lblPreach.text                  = preach.objectForKey("myPreach") as? String
        }
    }
    
    // MARK: - API Methods
    
    // MARK: - Action Methods
    
    @IBAction func btnBack_Action(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: - MemoryManagement Methods
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
