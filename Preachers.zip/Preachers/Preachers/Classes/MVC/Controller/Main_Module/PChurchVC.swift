//
//  PChurchVC.swift
//  Preachers
//
//  Created by Abel Anca on 10/7/15.
//  Copyright © 2015 Abel Anca. All rights reserved.
//

import UIKit
import Parse

class PChurchVC: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var imgChurch: UIImageView!
    
    @IBOutlet var lblNameAndCity: UILabel!
    @IBOutlet var lblPastor: UILabel!
    @IBOutlet var lblAddress: UILabel!
    @IBOutlet var lblDistance: UILabel!
    @IBOutlet var lblVisits: UILabel!
    @IBOutlet var lblNote: UITextView!
    
    @IBOutlet var btnEditVisits: UIButton!
    @IBOutlet var btnAddVisit: UIButton!
    @IBOutlet var btnBack: UIButton!
    @IBOutlet var tblView: UITableView!
    
    var arrPreaches: [PFObject]?
    var currentChurch: PFObject?
    
    var nrVisits: Int?
    var objId: String?
    
    var isEdit                                 = false

    // MARK: - ViewController Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        loadPreach()
    }
    
    // MARK: - Custom Methods
    
    func setupUI() {
        btnEditVisits.backgroundColor           = UIColor.clearColor()
        btnEditVisits.layer.cornerRadius        = 5
        btnEditVisits.layer.borderWidth         = 2
        btnEditVisits.layer.borderColor         = UIColor.whiteColor().CGColor
        btnEditVisits.clipsToBounds             = true
        
        btnAddVisit.backgroundColor             = UIColor.clearColor()
        btnAddVisit.layer.cornerRadius          = 5
        btnAddVisit.layer.borderWidth           = 2
        btnAddVisit.layer.borderColor           = UIColor.whiteColor().CGColor
        btnAddVisit.clipsToBounds               = true
        
        btnBack.layer.cornerRadius              = 17
        btnBack.layer.borderWidth               = 0.5
        btnBack.layer.borderColor               = UIColor.whiteColor().CGColor
        btnBack.clipsToBounds                   = true
        
        tblView.tableFooterView                 = UIView()
        
        loadParams()
    }
    
    func loadParams() {
        if let objectId = objId {
            let query = PFQuery(className:"Church")
            query.getObjectInBackgroundWithId(objectId, block: { (object, error) -> Void in
                if error == nil {
                    self.currentChurch = object
                    self.updateParams()
                    self.loadPreach()
                }
            })
        }
    }
    
    func updateParams() {
        if let church = currentChurch {
            let city                = church.objectForKey("city") as! String
            let name                = church.objectForKey("name") as? String
            
            if let name = name {
                lblNameAndCity.text = "\(name) \(city)"
            }
            
            let address = church.objectForKey("address") as? String
            if let address = address {
                lblAddress.text     = "\(address)"
            }
            
            let distance = church.objectForKey("distance") as? String
            if let distance = distance {
                lblDistance.text    = "\(distance)"
            }
            
            let pastor = church.objectForKey("pastor") as? String
            if let pastor = pastor {
            lblPastor.text          = "\(pastor)"
            }
            
            let note = church.objectForKey("note") as? String
            if let note = note {
                lblNote.text        = note
            }
            
            if let userPicture = church.objectForKey("image") as? PFFile {
                userPicture.getDataInBackgroundWithBlock({ (data, error) -> Void in
                    if error == nil {
                        if let imageData = data {
                            if let image = UIImage(data:imageData) {
                                if image.size == CGSizeMake(200, 200) {
                                    self.imgChurch.backgroundColor  = UIColor.blackColor()
                                    self.imgChurch.image            = UIImage(named: "Old_Church")
                                }
                                else {
                                    self.imgChurch.image            = image
                                }
                            }
                        }
                    }
                    else {
                    }
                })
            }
        }
    }
    
    // MARK: - API Methods
    
    func loadPreach() {
        let query = PFQuery(className:"Preach")
        if let church = currentChurch {
            query.whereKey("church", equalTo: church)
            query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                if error == nil {
                    self.nrVisits         = objects?.count
                    self.arrPreaches      = objects
                    
                    self.tblView.reloadData()
                }
            }
        }
    }
    
    // MARK: - UITableViewDataSource Methods
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let churchs = arrPreaches {
            lblVisits.text          = "\(churchs.count)"
            
            if churchs.count == 0 {
                btnEditVisits.hidden = true
            }
            else {
                btnEditVisits.hidden = false
            }
            return churchs.count
        }
        
        lblVisits.text              = "0"
        return 0
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("PVisitCell", forIndexPath: indexPath) as! PVisitCell

        if let preaches = arrPreaches {
            let preach              = preaches[indexPath.row]
            let date                = preach.objectForKey("date") as? String
            let index               = String(indexPath.row + 1)
            
            cell.lblDate.text       = "\(index). \(date!)"
        }
        return cell
    }

    // MARK: - UITableViewDelegate Methods
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if isEdit == true {
            let editChurchVC         = self.storyboard?.instantiateViewControllerWithIdentifier("PEditVisitVC") as! PEditVisitVC
            if let preachs           = arrPreaches {
                let preach           = preachs[indexPath.row]
                editChurchVC.objId   = preach.objectId
            }
            self.presentViewController(editChurchVC, animated: true, completion: nil)
        }
        else {
            let editChurchVC         = self.storyboard?.instantiateViewControllerWithIdentifier("PPreachVC") as! PPreachVC
            if let preachs           = arrPreaches {
                let preach           = preachs[indexPath.row]
                editChurchVC.objId   = preach.objectId
            }
            editChurchVC.modalTransitionStyle = .CrossDissolve
            self.presentViewController(editChurchVC, animated: true, completion: nil)
        }
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            
            let query = PFQuery(className:"Preach")
            if let church = currentChurch {
                query.whereKey("church", equalTo: church)
                query.findObjectsInBackgroundWithBlock { (objects, error) -> Void in
                    if error == nil {
                        if let objects = objects {
                            let object = objects[indexPath.row]
                            object.deleteInBackground()
                        }
                    }
                }
                
                arrPreaches?.removeAtIndex(indexPath.row)
                tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
            }
        }
    }
    
    // MARK: - Action Methods
    
    @IBAction func btnAddVisits_Action(sender: AnyObject) {
        let addChurchVC              = storyboard?.instantiateViewControllerWithIdentifier("PAddVisitVC") as! PAddVisitVC
        addChurchVC.currentChurch    = self.currentChurch
        presentViewController(addChurchVC, animated: true, completion: nil)
    }
    @IBAction func btnEditVisits_Action(sender: AnyObject) {
        if isEdit == false {
            isEdit                   = true
            tblView.editing          = true
        }
        else {
            isEdit                   = false
            tblView.editing          = false
        }
    }
    
    @IBAction func btnBack_Action(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }

    // MARK: - MemoryManagement Methods
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
