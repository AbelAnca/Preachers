//
//  PVisitCell.swift
//  Preachers
//
//  Created by Abel Anca on 10/13/15.
//  Copyright © 2015 Abel Anca. All rights reserved.
//

import UIKit

class PVisitCell: UITableViewCell {

    @IBOutlet var lblDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
